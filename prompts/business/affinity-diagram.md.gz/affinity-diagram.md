---
title: "유사성 다이어그램"
description: "업무 효율화 방법을 유사성 다이어그램으로 정리하는 프롬프트"
category: "Business"
tags: ["유사성다이어그램", "업무효율화", "분류정리", "체계화", "프로세스개선"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[ ] 업무를 효율화하는 방법을 생각하고, 유사성 다이어그램(Affinity Diagram)으로 정리해 주세요.
