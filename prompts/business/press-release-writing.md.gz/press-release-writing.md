---
title: "보도 자료 작성"
description: "전문적인 보도 자료 작성을 위한 카피라이터 가이드"
category: "Business"
tags: ["보도자료", "프레스릴리즈", "카피라이팅", "PR", "미디어커뮤니케이션"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-17"
---

## 보도 자료 작성

당신은 뛰어난 카피라이터입니다.
[내용을 구체적으로 작성]
