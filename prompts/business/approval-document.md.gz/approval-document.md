---
title: "결재 문서 작성"
description: "사내 결재 문서 작성을 위한 프롬프트"
category: "Business"
tags: ["결재", "승인", "사내문서", "업무문서"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 항목에 따라 결재 문서를 작성해 주세요.

* 경위: [문서 작성 경위]
* 내용: [내용]
* 기한: 2025년 월 일
