---
title: "일정 관리"
description: "프로젝트 및 업무 일정 계획 수립을 위한 프롬프트"
category: "Business"
tags: ["일정관리", "프로젝트계획", "스케줄링", "업무계획"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

오늘은 [N]월 [N]일입니다.
[목표한 기간]까지 [제품명]의 신제품 출시를 위한 일정을 세워 주세요.
표 형식으로 붙여 넣을 수 있도록 해 주세요.
