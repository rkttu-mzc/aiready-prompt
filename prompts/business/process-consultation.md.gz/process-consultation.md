---
title: "진행 방법 상담"
description: "업무 진행 방법 및 절차에 대한 상담을 위한 프롬프트"
category: "Business"
tags: ["상담", "업무절차", "프로세스", "업무가이드"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[업무 주관 부서명] 업무를 해외 [내용]할 때 어떻게 진행해야 하나요?
각 단계의 세부 내용을 제시해 주세요.
