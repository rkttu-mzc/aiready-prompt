---
title: "장단점 제시"
description: "특정 상품이나 서비스의 장점과 단점을 균형있게 분석하는 프롬프트"
category: "Business"
tags: ["장단점분석", "균형분석", "객관적평가", "리스크분석", "의사결정"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[ ] 사용의 장점과 단점을 각각 5가지씩 제시해 주세요.
