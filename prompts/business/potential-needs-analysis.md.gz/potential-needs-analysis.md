---
title: "고객의 잠재적 니즈 파악"
description: "현재 존재하지 않는 상품이나 서비스에 대한 고객 니즈를 파악하는 프롬프트"
category: "Business"
tags: ["고객니즈", "잠재니즈", "미래상품", "혁신", "시장기회"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[고객의 니즈 파악을 위한 질문]
현재 존재하지 않는 상품이나 서비스에 한정해 주세요.
