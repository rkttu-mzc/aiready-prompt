---
title: "평가 항목 설정"
description: "사업 계획 평가를 위한 평가 항목과 기준을 설정하는 프롬프트"
category: "Business"
tags: ["평가기준", "사업계획", "평가항목", "성과측정", "기준설정"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[ ] 업체인 당사의 [ ] 사업 계획을 평가할 때 필요한 평가 항목과 평가 기준을 알려 주세요.
