---
title: "번역 요청"
description: "비즈니스 문서 번역을 위한 프롬프트"
category: "Business"
tags: ["번역", "다국어", "현지화", "국제화"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음의 지시문을 [ ]로 번역하고, 웹사이트에 게시할 수 있는 [ ] 형식으로 사용하기 위해 존댓말 형식(입니다, 합니다 등)을 사용해 주세요.

[영문 붙여 넣기]
