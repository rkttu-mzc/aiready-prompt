---
title: "회의 어젠더 작성"
description: "회의 안건 및 어젠더 작성을 위한 프롬프트"
category: "Business"
tags: ["회의", "어젠더", "안건", "회의운영"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 회의의 어젠더를 작성해 주세요.

* 목적: [회의 목적을 작성]
* 참석자:
* 시간:
