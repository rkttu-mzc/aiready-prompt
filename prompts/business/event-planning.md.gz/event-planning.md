---
title: "이벤트 기획"
description: "특정 조건에 맞는 이벤트를 기획하고 제안하는 프롬프트"
category: "Business"
tags: ["이벤트기획", "마케팅이벤트", "행사기획", "프로모션", "고객참여"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 조건을 충족하는 이벤트 기획 및 제안을 해 주세요.

* 목적: [ ]
* 시기: [ ]
* 내용: [ ]
