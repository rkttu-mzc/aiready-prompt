---
title: "논점·관점 도출"
description: "컨설팅 관점에서 검토해야 할 논점과 관점을 도출하는 프롬프트"
category: "Business"
tags: ["컨설팅", "논점도출", "관점분석", "검토사항", "전략"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

당신은 [ ] 컨설턴트입니다.
[내용 작성]
검토해야 할 관점을 알려 주세요.
