---
title: "기획서 작성"
description: "SNS 마케팅 기획서를 체계적으로 작성하는 프롬프트"
category: "Business"
tags: ["기획서", "SNS마케팅", "마케팅전략", "소셜미디어", "문서작성"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 내용을 포함하여 SNS 마케팅 기획서를 작성해 주세요.
[ ]
