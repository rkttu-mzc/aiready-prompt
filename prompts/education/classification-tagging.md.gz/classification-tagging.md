---
title: "분류 및 태그 지정"
description: "설문 응답이나 텍스트를 주요 키워드로 태그하고 분류하는 프롬프트"
category: "Education"
tags: ["분류", "태그지정", "키워드추출", "데이터정리"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

## 분류 및 태그 지정

다음 설문 응답을 주요 키워드로 태그하고 분류해 주세요.

응답 1: [ ]
응답 2: [ ]
응답 3: [ ]
