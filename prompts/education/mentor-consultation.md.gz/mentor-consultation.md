---
title: "멘토에게 상담"
description: "직장인의 다양한 고민과 문제에 대해 멘토의 조언을 구하는 상담 프롬프트"
category: "Education"
tags: ["멘토링", "직장인상담", "경력상담", "조언"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

저는 30대 직장인 김사원입니다.
[상담 받고 싶은 내용]
