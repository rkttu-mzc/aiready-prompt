---
title: "영문 이력서 작성"
description: "한국어 이력서를 바탕으로 글로벌 기준에 맞는 영문 CV를 작성하는 프롬프트"
category: "Education"
tags: ["영문이력서", "CV", "글로벌채용", "영어"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 한국어 이력서를 바탕으로,
[ ]을 최대한 어필할 수 있는 최고의 영문 CV를 작성해 주세요.

【한국어 이력서】:
