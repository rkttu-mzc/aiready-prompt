---
title: "최신 뉴스 정보 수집"
description: "특정 주제에 대한 최신 뉴스를 한글로 수집하고 정리하는 프롬프트"
category: "Education"
tags: ["최신뉴스", "정보수집", "뉴스요약", "시사정보"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

## 정보 수집 (최신 뉴스)

[ ]에 관한 최신 뉴스를 한글로 알려 주세요.
