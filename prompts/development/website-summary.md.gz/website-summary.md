---
title: "웹사이트 요약"
description: "WebPilot GPTs를 이용한 웹사이트 콘텐츠 요약 프롬프트"
category: "Development"
tags: ["웹요약", "WebPilot", "콘텐츠분석", "WebPilot", "GPTs"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음을 요약해 주세요.

[웹사이트 주소]
