---
title: "비즈니스 모델 도식화"
description: "Whimsical Diagrams GPTs를 이용한 비즈니스 모델 도식화 프롬프트"
category: "Development"
tags: ["다이어그램", "Whimsical", "도식화", "비즈니스모델", "도해"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[ ]의 비즈니스 모델을 도식화해 주세요.
