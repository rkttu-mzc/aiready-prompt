---
title: "목록 번호 매기기"
description: "텍스트 목록에 자동으로 번호를 매기는 프롬프트"
category: "Development"
tags: ["텍스트처리", "번호매기기", "목록정리", "포맷팅", "자동화"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 목록에 번호를 붙여 주세요. (1)부터 시작하여 (1)(2)(3) 형식으로 표기해 주세요.

[목록을 작성할 내용]
