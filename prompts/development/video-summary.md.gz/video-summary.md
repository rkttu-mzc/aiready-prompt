---
title: "동영상 요약"
description: "Voxscript GPTs를 이용한 유튜브 동영상 요약 프롬프트"
category: "Development"
tags: ["동영상요약", "Voxscript", "유튜브", "콘텐츠분석", "GPTs"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

동영상을 요약해 주세요.

[유튜브 링크]
