---
title: "Excel 함수 설명"
description: "Excel 함수 사용법 및 기능 설명을 위한 프롬프트"
category: "Development"
tags: ["Excel", "함수", "스프레드시트", "데이터분석", "오피스"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[엑셀 사용 시 발생하는 질문 입력]
