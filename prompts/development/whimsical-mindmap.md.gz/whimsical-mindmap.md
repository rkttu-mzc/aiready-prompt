---
title: "마인드맵 작성"
description: "Whimsical Diagrams GPTs를 이용한 마인드맵 작성 프롬프트"
category: "Development"
tags: ["마인드맵", "Whimsical", "정리", "구조화", "시각화"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

[ ]할 사항을 마인드맵 형식으로 한글로 정리해 주세요.
