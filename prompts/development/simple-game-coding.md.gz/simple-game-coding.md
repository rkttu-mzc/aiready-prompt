---
title: "간단한 게임 코딩"
description: "Python으로 작성하는 간단한 숫자 맞추기 게임 코드 작성 프롬프트"
category: "Development"
tags: ["프로그래밍", "Python", "게임", "코딩", "초보자"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

컴퓨터에서 작동하는 간단한 게임 코드를 작성해 주세요.

* 생성할 내용: Python으로 작성된 간단한 숫자 맞추기 게임 코드
* 주의 사항: 코드와 함께 게임 설명도 포함해 주세요.
