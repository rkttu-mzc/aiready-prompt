---
title: "Excel 매크로(VBA) 작성"
description: "Excel VBA 매크로 코드 작성 및 설명을 위한 프롬프트"
category: "Development"
tags: ["Excel", "VBA", "매크로", "자동화", "프로그래밍"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음과 같은 Excel 매크로를 작성해 주세요.
[엑셀 매크로 내용]
