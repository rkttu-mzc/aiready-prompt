---
title: "프레젠테이션 자료의 대본 작성"
description: "슬라이드 내용에 맞는 프레젠테이션 대본 작성을 위한 프롬프트"
category: "Writing"
tags: ["프레젠테이션", "대본", "스피치", "발표"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 슬라이드 내용에 맞춰 프레젠테이션 대본을 작성해 주세요.

제목: [ ]
구성: [ ]
