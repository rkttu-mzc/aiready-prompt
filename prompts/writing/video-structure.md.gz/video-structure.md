---
title: "동영상 구성안 작성"
description: "영상 콘텐츠의 체계적인 구성안 및 시나리오 작성을 위한 프롬프트"
category: "Writing"
tags: ["동영상", "구성안", "시나리오", "영상기획"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 영상의 구성안을 한글로 만들어 주세요.

[내용]
