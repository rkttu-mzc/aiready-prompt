---
title: "동영상 자동 생성"
description: "AI를 활용한 영상 콘텐츠 자동 생성을 위한 프롬프트"
category: "Writing"
tags: ["동영상", "AI영상생성", "자동화", "영상AI"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음의 영상을 만들어 주세요.

[영상의 제목, 내용, 길이 등]
