---
title: "동영상 대본 작성"
description: "영상 콘텐츠의 상세한 대본 및 내레이션 작성을 위한 프롬프트"
category: "Writing"
tags: ["동영상", "대본", "내레이션", "스크립트"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 영상의 대본을 작성해 주세요.

[영상의 제목 아이디어 및 구성안 등]
