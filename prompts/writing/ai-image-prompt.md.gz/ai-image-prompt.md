---
title: "이미지 생성 AI의 프롬프트 작성"
description: "Midjourney 등 이미지 생성 AI를 위한 효과적인 프롬프트 작성 가이드"
category: "Writing"
tags: ["AI이미지생성", "Midjourney", "프롬프트엔지니어링", "이미지AI","Midjourney"]
author: "Cloud Tech Unit"
created: "2025-06-16"
updated: "2025-06-16"
---

다음 이미지를 만들기 위한 프롬프트를 영어로 작성해 주세요.
이미지는 작성하지 마세요. txt 코드 블록에 모두 작성해주세요. 모든 것을 포함해주세요.

[이미지 생성을 위한 내용]
